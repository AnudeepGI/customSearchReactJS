import React from 'react';
import './App.css';
import Header from './components/Header/Header';
import NavRoutes from './components/NavRoutes/NavRoutes';

function App() {
  return (
    <>
      <Header />
      <NavRoutes />
    </>
  );
}

export default App;

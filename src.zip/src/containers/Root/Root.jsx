import React, { useState, useEffect, useContext } from 'react';
import { DataContext } from "../../state/context";
import { FormControl, Grid, IconButton, InputAdornment, InputLabel, MenuItem, OutlinedInput, Select, Chip, Box, Checkbox, Typography } from "@mui/material";
import SearchIcon from '@mui/icons-material/Search';
import styles from "./Root.module.css";
import { useNavigate } from "react-router-dom";
import { GET_POKEMONS } from '../../state/actions';
import getPokemonData from '../../apis/pokemon';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
        },
    },
};

const pokemonTypes = [
    'Normal',
    'Fire',
    'Water',
    'Grass',
    'Electric',
    'Ice',
    'Fighting',
    'Poison',
    'Ground',
    'Flying',
    'Psychic',
    'Bug',
    'Rock',
    'Ghost',
    'Dragon',
    'Dark',
    'Steel',
    'Fairy',
];

function Root() {
    let navigate = useNavigate();

    const { state, dispatch } = useContext(DataContext);

    const [search, setSearch] = useState("");
    const [type, setType] = useState([]);
    const [weakness, setWeakness] = useState([]);

    const [pokemons, setPokemonData] = useState([]);

    useEffect(() => {
        getPokemonData().then(payload => {
            setPokemonData(payload);

            dispatch({
                type: GET_POKEMONS,
                payload
            });
        });
    }, []);

    useEffect(() => {
        if (Array.isArray(state.pokemons) && state.pokemons.length > 0) {
            let filteredArray = [];

            // Filter Pokemon's based on Search
            if (search !== null && search !== "") {
                filteredArray = ((pokemons.length > 0 && pokemons) || (state.pokemons)).filter(pokemon => {
                    return ((pokemon.name).toString().toLowerCase().startsWith(search.toString().toLowerCase()));
                });
            }

            // Filter Pokemon's based on Type
            if (Array.isArray(type) && type.length > 0) {
                filteredArray = ((filteredArray.length > 0 && filteredArray) || (state.pokemons)).filter(pokemon => {
                    return type.every(i => (pokemon.type).includes(i))
                })
            }

            // Filter Pokemon's based on Weakness
            if (Array.isArray(weakness) && weakness.length > 0) {
                filteredArray = ((filteredArray.length > 0 && filteredArray) || (state.pokemons)).filter(pokemon => {
                    return weakness.every(i => (pokemon.weaknesses).includes(i))
                })
            }

            setPokemonData(filteredArray.length > 0 ? filteredArray : state.pokemons);
        }
    }, [search, type, weakness]);

    return (
        <>
            <Grid container justifyContent={"center"}>
                <Grid item md={11}>
                    <Grid container justifyContent={"center"}>
                        <FormControl sx={{ m: 1, width: 500 }} variant="outlined">
                            <OutlinedInput
                                variant="outlined"
                                type='text'
                                value={search}
                                onChange={({ target: { value } }) => { setSearch(value) }}
                                placeholder="Search for Pokemon's"
                                endAdornment={
                                    <InputAdornment position="end">
                                        <IconButton edge="end">
                                            <SearchIcon />
                                        </IconButton>
                                    </InputAdornment>
                                }
                            />
                        </FormControl>
                        <FormControl sx={{ m: 1, width: 300 }}>
                            <InputLabel id="type-label">Type</InputLabel>
                            <Select
                                labelId="type-label"
                                id="type"
                                multiple
                                value={type}
                                onChange={({ target: { value } }) => { setType(typeof value === 'string' ? value.split(',') : value) }}
                                input={<OutlinedInput id="select-multiple-type" label="Type" />}
                                renderValue={(selected) => (
                                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                        {selected.map((value) => (
                                            <Chip key={value} label={value} />
                                        ))}
                                    </Box>
                                )}
                                MenuProps={MenuProps}
                            >
                                {
                                    pokemonTypes.map((pokemonType) => (
                                        <MenuItem
                                            key={pokemonType}
                                            value={pokemonType}
                                        >
                                            <Checkbox checked={type.indexOf(pokemonType) > -1} />
                                            {pokemonType}
                                        </MenuItem>
                                    ))}
                            </Select>
                        </FormControl>
                        <FormControl sx={{ m: 1, width: 300 }}>
                            <InputLabel id="weakness-label">Weakness</InputLabel>
                            <Select
                                labelId="weakness-label"
                                id="weakness"
                                multiple
                                value={weakness}
                                onChange={({ target: { value } }) => { setWeakness(typeof value === 'string' ? value.split(',') : value) }}
                                input={<OutlinedInput id="select-multiple-weakness" label="Weakness" />}
                                renderValue={(selected) => (
                                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                        {selected.map((value) => (
                                            <Chip key={value} label={value} />
                                        ))}
                                    </Box>
                                )}
                                MenuProps={MenuProps}
                            >
                                {
                                    pokemonTypes.map((pokemonType) => (
                                        <MenuItem
                                            key={pokemonType}
                                            value={pokemonType}
                                        >
                                            <Checkbox checked={weakness.indexOf(pokemonType) > -1} />
                                            {pokemonType}
                                        </MenuItem>
                                    ))}
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid>
                        <Grid className={styles.pokemoncontainer} item>
                            <Grid container flexWrap="nowrap">
                                {
                                    pokemons.map((pokemon) => (
                                        <Grid className={styles.card} item key={pokemon.id} onClick={() => {navigate(`/details?id=${pokemon.id}`)}}>
                                            <img src={pokemon.img} />
                                            <Typography>{pokemon.name}</Typography>
                                            <br/>
                                            <Typography>{pokemon.num}</Typography>
                                            <br/>
                                            <Typography>
                                                Type<br/>
                                                {
                                                    Array.isArray(pokemon.type) && pokemon.type.join(", ")
                                                }
                                            </Typography>
                                            <br/>
                                            <Typography>
                                                Weakness<br/>
                                                {
                                                    Array.isArray(pokemon.weaknesses) && pokemon.weaknesses.join(", ")
                                                }
                                            </Typography>
                                        </Grid>
                                    ))
                                }
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </>);
}

export default Root;

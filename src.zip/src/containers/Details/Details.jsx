import React, { useState, useEffect, useContext } from 'react';
import { GET_POKEMONS } from '../../state/actions';
import { DataContext } from "../../state/context";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Grid, Typography } from "@mui/material";
import styles from "./Details.module.css";
import getPokemonData from '../../apis/pokemon';

function Details() {
	const { state, dispatch } = useContext(DataContext);

	const [pokemon, setPokemon] = useState({});
	// const [bool, setBool] = useState(false);
	// let navigate = useNavigate();

	let [searchParams, setSearchParams] = useSearchParams();

	useEffect(() => {
		if (state.pokemons.length > 0) {
			filterPokemons();
		}
		else {
			getPokemonData().then(payload => {
				dispatch({
					type: GET_POKEMONS,
					payload
				});
			})
		}
	}, [state]);

	const filterPokemons = () => {
		let tempArr = (state.pokemons).filter(pokemon => (pokemon.id === parseInt(searchParams.get("id"))));

		setPokemon(tempArr[0]);
	}

	// const goToEvloution = (id) => {
	// 	navigate(`/details?id=${id}`, {
	// 		replace: false,
	// 	});
	// 	setBool(!bool);
	// }

	return (
		<div>
			<Grid container justifyContent={"center"} alignItems={"center"}>
				<Grid className={styles.card} item md={4}>
					<img src={pokemon.img} />
					<Typography>{pokemon.name}</Typography>
					<br />
					<Typography>{pokemon.num}</Typography>
					<br />
					<Typography>
						Type<br />
						{
							Array.isArray(pokemon.type) && pokemon.type.join(", ")
						}
					</Typography>
					<br />
					<Typography>
						Weakness<br />
						{
							Array.isArray(pokemon.weaknesses) && pokemon.weaknesses.join(", ")
						}
					</Typography>
					<br />
					<Typography>
						Height<br />{pokemon.height}
					</Typography>
					<br />
					<Typography>
						Weight<br />{pokemon.weight}
					</Typography>
					{
						pokemon["prev_evolution"] &&
						pokemon["prev_evolution"] !== null &&
						<>
							<br />
							<div>
								Previous Evolution<br />
								<ul>
									{
										pokemon["prev_evolution"].map(prev => {
											return (
												<li key={prev.num}>
													<a href={`/details?id=${parseInt(prev.num)}`}>{prev.name}</a>
												</li>
											)
										})
									}
								</ul>
							</div>
						</>
					}
					{
						pokemon["next_evolution"] &&
						pokemon["next_evolution"] !== null &&
						<>
							<br />
							<div>
								Next Evolution<br />
								<ul>
									{
										pokemon["next_evolution"].map(next => {
											return (
												<li key={next.num}>
													<a href={`/details?id=${parseInt(next.num)}`}>{next.name}</a>
												</li>
											);
										})
									}
								</ul>
							</div>
						</>
					}
				</Grid>
			</Grid>
		</div>
	);
}

export default Details;

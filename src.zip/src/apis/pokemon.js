import axios from 'axios';

async function getPokemonData() {
    return axios.get("https://raw.githubusercontent.com/Biuni/PokemonGO-Pokedex/master/pokedex.json")
        .then((data) => {
            if (data.status === 200) {
                return data.data.pokemon
            }
            else {
                throw new Error("Error Occured");
            }
        })
        .catch((error) => {
            console.log(error);
            alert("API Failed");
        });
}

export default getPokemonData;

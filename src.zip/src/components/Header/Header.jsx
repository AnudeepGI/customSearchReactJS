import React from 'react';
import { Grid, Typography } from '@mui/material';
import styles from "./Header.module.css";

function Header() {
    return (
        <Grid item md={12} className={styles.header}>
            <Grid container justifyContent={"center"} alignItems={"center"} style={{ padding: ".5rem" }}>
                <img src='./pokeball.png' style={{ width: "3%" }} alt="Pokeball"/>
                <Typography style={{ margin: "0 0.5rem"}}>Pokedex</Typography>
            </Grid>
        </Grid>
    );
}

export default Header;

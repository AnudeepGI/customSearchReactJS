const GET_POKEMONS = "GET_POKEMONS";

export {
    GET_POKEMONS
};